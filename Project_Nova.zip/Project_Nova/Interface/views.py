from typing import Annotated
from django.shortcuts import redirect, render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import *
from .models import *

# Create your views here.

@login_required
def announcement(request):
    annonces = {
        'announcements': Announcement.objects.all(),
        'teacher': TeacherStudent.objects.all()
    }
    return render(request, 'Interface/announcements.html', annonces)


@login_required
def assignment(request):
    assignments = {
        'assignments': Assignment.objects.all()
    }
    return render(request, 'Interface/assignments.html', assignments)

def home(request):
    return render(request, 'Interface/home.html')


@login_required
def AnnouncementCreate(request):
    if request.method == "POST":
        form = AnnouncementForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('announcements')
        else:
            return render(request, 'Interface/announcement_form.html', {'form':form})
    else:
        form = AnnouncementForm()
        return render(request, 'Interface/announcement_form.html', {'form':form})


@login_required
def AssignmentCreate(request):
    if request.method == "POST":
        form = AssignmentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('assignments')

        else:
            return render(request, 'Interface/assignment_form.html', {'form':form})
    else:
        form = AssignmentForm()
        return render(request, 'Interface/assignment_form.html', {'form':form})

@login_required
def submit_assignment(request,pk):
    obj = Assignment.objects.get(pk=pk)
    item = get_object_or_404(Assignment, pk=pk)
    if request.method == 'POST':
        form = SubmitForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('assignments')
    else:
        form = SubmitForm(instance=obj)
        return render(request, 'Interface/assignment_form.html', {'form':form})
    