from django.contrib import admin
from .models import Announcement, Assignment, StudentAttendance, TeacherAttendance, TeacherStudent

# Register your models here.
admin.site.register(Announcement)
admin.site.register(Assignment)
admin.site.register(TeacherStudent)
admin.site.register(TeacherAttendance)
admin.site.register(StudentAttendance)
