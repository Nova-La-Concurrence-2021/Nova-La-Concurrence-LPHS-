from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

# Create your models here.

class Announcement(models.Model):
    teacher = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    description = models.TextField()
    date_posted = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return '{0}: {1}'.format(self.teacher, self.title)

    def get_absolute_url(self):
        return reverse('announcements')

class Assignment(models.Model):
    teacher = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    description = models.TextField()
    date_posted = models.DateTimeField(default=timezone.now)
    document = models.FileField(upload_to='documents/%Y/%m/%d')
    marks = models.PositiveIntegerField()

    def __str__(self):
        return '{0}'.format(self.title)

class TeacherStudent(models.Model):
    teacher = models.ForeignKey(User, on_delete=models.CASCADE)
    ifteacher = models.CharField(max_length=10)
    emailid = models.EmailField()

class TeacherAttendance(models.Model):
    choice = (('Present', 'Present'),
            ('Absent', 'Absent'))


    teacher = models.ForeignKey(User, on_delete=models.CASCADE)
    tattendance = models.CharField(max_length=15, choices=choice, default=[1][0])


class StudentAttendance(models.Model):
    choice = (('Present', 'Present'),
            ('Absent', 'Absent'))

    student = models.ForeignKey(User, on_delete=models.CASCADE)
    tattendance = models.CharField(max_length=15, choices=choice, default=[1][0])