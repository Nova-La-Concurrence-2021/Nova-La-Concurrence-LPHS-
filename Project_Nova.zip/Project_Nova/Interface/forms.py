from django import forms
from django.db.models import fields
from .models import *

class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ('title', 'description')


class AssignmentForm(forms.ModelForm):
    class Meta:
        model = Assignment
        fields = ('title', 'description', 'document', 'marks')


class SubmitForm(forms.ModelForm):
    submission = forms.FileField()
    class Meta:
        model = Assignment
        fields = ('title', 'description', 'document', 'marks')
        exclude = ('title', 'description', 'document', 'marks')

class GradeForm(forms.ModelForm):
    outofmarks = forms.IntegerField()
    graded_submission = forms.FileField()
    
    class Meta:
        model = Assignment
        fields = ('title', 'description', 'document', 'marks')
        exclude = ('title', 'description', 'document', 'marks')
