from django.urls import path
from django.conf.urls import url
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('announcements/', views.announcement, name='announcements'),
    path('announcements/new/', views.AnnouncementCreate, name='announcement-create'),
    path('assignments/', views.assignment, name='assignments'),
    path('assignments/new/', views.AssignmentCreate, name='assignment-create'),
    url(r'^assignment/(?P<pk>\d+)$', views.submit_assignment, name='submit-assignment'),
]